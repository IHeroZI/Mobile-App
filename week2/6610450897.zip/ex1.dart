void main() {
  double temperature = 20;
  int value = 2;
  String pizza = 'pizza';
  String pasta = 'pasta';

  print('''The temperature is ${temperature.toInt()}c
$value plus $value makes ${value + value}
I like $pizza and $pasta''');
}
