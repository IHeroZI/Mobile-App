import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          appBar: AppBar(
            title: const Text("Our Menu",
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.black)),
            centerTitle: true,
            actions: const [
              Icon(Icons.shopping_cart),
              Padding(
                padding: EdgeInsets.only(right: 16.0),
              ),
            ],
          ),
          body: GridView.count(
            primary: false,
            padding: const EdgeInsets.all(20),
            crossAxisSpacing: 20,
            mainAxisSpacing: 20,
            crossAxisCount: 2,
            children: const <Widget>[
              ProductBox(name: "ราเมง", price: 80, image: "1.jpg"),
              ProductBox(name: "ผัดซีอิ้ว", price: 60, image: "2.jpg"),
              ProductBox(name: "ไก่ย่าง", price: 65, image: "3.png"),
              ProductBox(name: "ข้าวผัด", price: 50, image: "4.png"),
              ProductBox(name: "ผัดไทย", price: 60, image: "5.png"),
              ProductBox(name: "สลัดผัก", price: 70, image: "6.jpg"),
              ProductBox(name: "ข้าวผัด", price: 50, image: "4.png"),
              ProductBox(name: "ผัดซีอิ้ว", price: 60, image: "2.jpg"),
              ProductBox(name: "ราเมง", price: 80, image: "1.jpg"),
              ProductBox(name: "ผัดไทย", price: 60, image: "5.png"),
            ],
          )),
    );
  }
}

class ProductBox extends StatelessWidget {
  const ProductBox(
      {super.key,
      required this.name,
      required this.price,
      required this.image});
  final String name;
  final int price;
  final String image;

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.all(2),
        height: 300,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.65),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 3), // Shadow position
            ),
          ],
        ),
        child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Stack(children: <Widget>[
                Image.asset("assets/images/" + image),
                const Align(
                    alignment: Alignment.topRight,
                    child: Icon(
                      Icons.favorite_border,
                      color: Colors.pink,
                      size: 24,
                    ))
              ]),
              Text(this.name),
              Text("${this.price.toString()} บาท")
            ]));
  }
}
